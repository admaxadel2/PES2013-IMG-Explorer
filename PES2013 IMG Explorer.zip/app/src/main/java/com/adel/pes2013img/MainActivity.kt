package com.adel.pes2013img

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max

data class AfEntry(val index: Int, val offset: Long, val size: Long)

class MainActivity : Activity() {
    private var archiveBytes: ByteArray? = null
    private var entries: List<AfEntry> = emptyList()
    private var selected = -1
    private lateinit var info: TextView
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val labels = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
        }
        val title = TextView(this).apply {
            text = "PES 2013 IMG Explorer"
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 16)
        }
        info = TextView(this).apply { text = "افتح ملف IMG من PES 2013 للبدء."; textSize = 14f }
        val open = Button(this).apply {
            text = "فتح ملف IMG"
            setOnClickListener { pickOpen() }
        }
        val export = Button(this).apply {
            text = "تصدير العنصر المحدد"
            setOnClickListener { exportSelected() }
        }
        val replace = Button(this).apply {
            text = "استبدال العنصر المحدد"
            setOnClickListener { pickReplacement() }
        }
        val add = Button(this).apply {
            text = "إضافة ملف إلى IMG"
            setOnClickListener { pickAddFile() }
        }
        val delete = Button(this).apply {
            text = "حذف العنصر المحدد"
            setOnClickListener { deleteSelected() }
        }
        val save = Button(this).apply {
            text = "حفظ IMG جديد"
            setOnClickListener { pickSave() }
        }
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, position, _ ->
                selected = position
                showSelected()
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(open)
        layout.addView(export)
        layout.addView(replace)
        layout.addView(add)
        layout.addView(delete)
        layout.addView(save)
        layout.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
    }

    private fun pickOpen() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, 10)
    }

    private fun pickReplacement() {
        if (selected < 0) { toast("اختر عنصراً أولاً"); return }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, 11)
    }

    private fun pickAddFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, 14)
    }

    private fun deleteSelected() {
        val current = archiveBytes ?: run { toast("افتح IMG أولاً"); return }
        if (selected !in entries.indices) { toast("اختر عنصراً أولاً"); return }
        if (entries.size <= 1) { toast("لا يمكن حذف آخر عنصر من أرشيف AFS"); return }
        try {
            val payloads = entries.filterIndexed { index, _ -> index != selected }.map { e ->
                current.copyOfRange(e.offset.toInt(), (e.offset + e.size).toInt())
            }
            val alignment = detectAlignment(entries)
            archiveBytes = buildAfs(payloads, alignment)
            entries = parseAfs(archiveBytes!!)
            selected = -1
            refreshList()
            toast("تم حذف العنصر من الذاكرة. احفظ IMG جديداً لتثبيت التعديل.")
        } catch (e: Exception) {
            toast("تعذر الحذف: ${e.message}")
        }
    }

    private fun pickSave() {
        if (archiveBytes == null) { toast("افتح ملف IMG أولاً"); return }
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, "PES2013_modified.img")
        }
        startActivityForResult(i, 12)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (data.data == null && !(requestCode == 14 && data.clipData != null)) return
        val uri = data.data ?: data.clipData!!.getItemAt(0).uri
        try {
            when (requestCode) {
                10 -> {
                    val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    val parsed = parseAfs(bytes)
                    archiveBytes = bytes
                    entries = parsed
                    selected = -1
                    labels.clear()
                    parsed.forEach {
                        labels.add(String.format(
                            "Entry_%04d.bin  |  %s bytes  |  0x%X",
                            it.index, it.size, it.offset
                        ))
                    }
                    adapter.notifyDataSetChanged()
                    info.text = "AFS صالح — ${parsed.size} مدخل — ${bytes.size} بايت"
                    toast("تم فتح الملف بنجاح")
                }
                11 -> {
                    val replacement = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    val old = archiveBytes ?: return
                    archiveBytes = replaceEntry(old, entries, selected, replacement)
                    entries = parseAfs(archiveBytes!!)
                    refreshList()
                    toast("تم استبدال العنصر في الذاكرة. اضغط حفظ IMG جديد.")
                }
                12 -> {
                    val bytes = archiveBytes ?: return
                    contentResolver.openOutputStream(uri, "w")!!.use { it.write(bytes) }
                    toast("تم حفظ ملف IMG المعدل")
                }
                13 -> {
                    val bytes = pendingExport ?: return
                    contentResolver.openOutputStream(uri, "w")!!.use { it.write(bytes) }
                    pendingExport = null
                    toast("تم تصدير BIN")
                }
                14 -> {
                    val current = archiveBytes ?: throw IllegalStateException("افتح IMG أولاً")
                    val incomingUris = mutableListOf<Uri>()
                    data.clipData?.let { clip ->
                        for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { incomingUris.add(it) }
                    }
                    if (incomingUris.isEmpty()) incomingUris.add(uri)
                    val payloads = entries.map { e ->
                        current.copyOfRange(e.offset.toInt(), (e.offset + e.size).toInt())
                    }.toMutableList()
                    incomingUris.forEach { selectedUri ->
                        val bytes = contentResolver.openInputStream(selectedUri)!!.use { it.readBytes() }
                        payloads.add(bytes)
                    }
                    archiveBytes = buildAfs(payloads, detectAlignment(entries))
                    entries = parseAfs(archiveBytes!!)
                    selected = entries.lastIndex
                    refreshList()
                    toast("تمت إضافة ${incomingUris.size} ملف/ملفات. احفظ IMG جديداً لتثبيت التعديل.")
                }
            }
        } catch (e: Exception) {
            toast("تعذر إكمال العملية: ${e.message}")
        }
    }

    private fun parseAfs(data: ByteArray): List<AfEntry> {
        require(data.size >= 8) { "الملف أصغر من ترويسة AFS" }
        require(data[0] == 0x41.toByte() && data[1] == 0x46.toByte() &&
                data[2] == 0x53.toByte() && data[3] == 0.toByte()) {
            "هذا الملف ليس AFS؛ الترويسة المتوقعة AFS\\\\0"
        }
        val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val count = b.getInt(4)
        require(count in 1..200000) { "عدد العناصر غير منطقي: $count" }
        require(8L + count.toLong() * 8L <= data.size.toLong()) { "جدول العناصر خارج حدود الملف" }
        val result = ArrayList<AfEntry>(count)
        for (i in 0 until count) {
            val off = b.getInt(8 + i * 8).toLong() and 0xffffffffL
            val size = b.getInt(12 + i * 8).toLong() and 0xffffffffL
            require(off <= data.size.toLong() && size <= data.size.toLong() - off) {
                "مدخل $i يشير إلى خارج الملف"
            }
            result.add(AfEntry(i, off, size))
        }
        return result
    }

    private fun refreshList() {
        labels.clear()
        entries.forEach { labels.add(String.format("Entry_%04d.bin  |  %s bytes  |  0x%X", it.index, it.size, it.offset)) }
        adapter.notifyDataSetChanged()
        info.text = "AFS — ${entries.size} مدخل — ${archiveBytes?.size ?: 0} بايت"
    }

    private fun showSelected() {
        val e = entries.getOrNull(selected) ?: return
        info.text = "العنصر ${e.index} | الإزاحة: 0x${e.offset.toString(16).uppercase()} | الحجم: ${e.size} بايت"
    }

    private fun exportSelected() {
        val data = archiveBytes ?: run { toast("افتح IMG أولاً"); return }
        val e = entries.getOrNull(selected) ?: run { toast("اختر عنصراً أولاً"); return }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, "unnamed_${e.index.toString().padStart(4, '0')}.bin")
        }
        pendingExport = data.copyOfRange(e.offset.toInt(), (e.offset + e.size).toInt())
        startActivityForResult(intent, 13)
    }

    private var pendingExport: ByteArray? = null

    private fun replaceEntry(data: ByteArray, list: List<AfEntry>, index: Int, replacement: ByteArray): ByteArray {
        require(index in list.indices) { "رقم العنصر غير صحيح" }
        val payloads = list.map { e ->
            if (e.index == index) replacement
            else data.copyOfRange(e.offset.toInt(), (e.offset + e.size).toInt())
        }
        return buildAfs(payloads, detectAlignment(list))
    }

    private fun detectAlignment(list: List<AfEntry>): Long {
        // Verified against dt04.img, dt05_a.img, dt05_r.img and dt0a.img:
        // all payload offsets are aligned to 0x800. dt0a's first payload
        // starts at 0x2000 only because its larger table rounds up to 0x800.
        return 0x800L
    }

    private fun buildAfs(payloads: List<ByteArray>, alignment: Long): ByteArray {
        require(payloads.size in 1..200000) { "عدد العناصر غير صالح" }
        val count = payloads.size
        val tableEnd = 8L + count.toLong() * 8L
        var cursor = align(tableEnd, alignment)
        val output = ByteArrayOutputStream()
        val table = ArrayList<Pair<Long, Long>>(count)

        for (payload in payloads) {
            cursor = align(cursor, alignment)
            table.add(cursor to payload.size.toLong())
            while (output.size().toLong() < cursor) output.write(0)
            output.write(payload)
            cursor += payload.size
        }

        val result = output.toByteArray()
        val header = ByteBuffer.wrap(result).order(ByteOrder.LITTLE_ENDIAN)
        header.put(byteArrayOf(0x41, 0x46, 0x53, 0x00))
        header.putInt(4, count)
        for (i in 0 until count) {
            require(table[i].first <= 0xffffffffL && table[i].second <= 0xffffffffL) {
                "حجم IMG تجاوز حدود AFS ذات 32 بت"
            }
            header.putInt(8 + i * 8, table[i].first.toInt())
            header.putInt(12 + i * 8, table[i].second.toInt())
        }
        // Keep the archive end padded to the same 0x800 sector boundary
        // used by the supplied PES 2013 IMG files.
        val paddedSize = align(result.size.toLong(), alignment).toInt()
        return if (paddedSize == result.size) result else result.copyOf(paddedSize)
    }

    private fun align(value: Long, boundary: Long): Long =
        ((value + boundary - 1) / boundary) * boundary

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
