plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.adel.pes2013img"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.adel.pes2013img"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-alpha"
    }
}
