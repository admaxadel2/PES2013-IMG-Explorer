package com.adel.pes2013img

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.widget.*
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors

private data class AfEntry(val index: Int, val offset: Long, val size: Long)
private data class Payload(val file: File, val offset: Long, val size: Long)

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private var archiveFile: File? = null
    private var entries: List<AfEntry> = emptyList()
    private var selected = -1
    private lateinit var info: TextView
    private lateinit var adapter: ArrayAdapter<String>
    private val labels = mutableListOf<String>()
    private val phoneLabels = mutableListOf<String>()
    private val phoneFiles = mutableListOf<File>()
    private lateinit var phoneAdapter: ArrayAdapter<String>
    private var phoneSelected = -1
    private var pendingExport: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8,8,8,8) }
        val title = TextView(this).apply { text = "PES 2013 IMG Explorer V9"; textSize = 20f; gravity = Gravity.CENTER; setPadding(0,6,0,8) }
        info = TextView(this).apply { text = "افتح IMG في اليسار، واختر ملفات الهاتف في اليمين."; textSize = 13f; setPadding(4,4,4,8) }
        fun button(caption: String, action: () -> Unit) = Button(this).apply { text = caption; setOnClickListener { action() } }
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        phoneAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, phoneLabels)
        val archiveList = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _,_,p,_-> selected=p; showSelected() }
        }
        val phoneList = ListView(this).apply {
            this.adapter = this@MainActivity.phoneAdapter
            setOnItemClickListener { _,_,p,_-> phoneSelected=p; info.text = "ملف الهاتف: ${phoneLabels.getOrNull(p) ?: ""}"; notifyDataSetChanged() }
        }
        val headers = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        headers.addView(TextView(this).apply { text="محتويات IMG"; gravity=Gravity.CENTER; textSize=16f }, LinearLayout.LayoutParams(0,-2,1f))
        headers.addView(TextView(this).apply { text="ملفات الهاتف"; gravity=Gravity.CENTER; textSize=16f }, LinearLayout.LayoutParams(0,-2,1f))
        val panes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        panes.addView(archiveList, LinearLayout.LayoutParams(0,-1,1f))
        panes.addView(phoneList, LinearLayout.LayoutParams(0,-1,1f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row1.addView(button("فتح IMG") { pickOpen() }, LinearLayout.LayoutParams(0,-2,1f))
        row1.addView(button("اختيار ملفات الهاتف") { pick(15,true) }, LinearLayout.LayoutParams(0,-2,1f))
        val row2 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row2.addView(button("إضافة / نقل") { addPhoneFiles() }, LinearLayout.LayoutParams(0,-2,1f))
        row2.addView(button("استبدال المحدد") { pick(11) }, LinearLayout.LayoutParams(0,-2,1f))
        val row3 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row3.addView(button("استخراج") { exportSelected() }, LinearLayout.LayoutParams(0,-2,1f))
        row3.addView(button("حذف") { deleteSelected() }, LinearLayout.LayoutParams(0,-2,1f))
        row3.addView(button("حفظ نسخة IMG") { pickSave() }, LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(row1); actions.addView(row2); actions.addView(row3)
        root.addView(title); root.addView(info); root.addView(headers); root.addView(panes, LinearLayout.LayoutParams(-1,0,1f)); root.addView(actions)
        setContentView(root)
    }

    private fun pickOpen() = pick(10)
    private fun pick(request: Int, multiple: Boolean = false) {
        if (request in listOf(11,14) && archiveFile == null) { toast("افتح IMG أولاً"); return }
        if (request == 11 && selected !in entries.indices) { toast("اختر عنصراً أولاً"); return }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="*/*"; addCategory(Intent.CATEGORY_OPENABLE); if(multiple) putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true) }
        startActivityForResult(i, request)
    }
    private fun pickSave() {
        if (archiveFile == null) { toast("افتح IMG أولاً"); return }
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/octet-stream"; putExtra(Intent.EXTRA_TITLE,"PES2013_modified.img") },12)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data==null) return
        val uris=mutableListOf<Uri>()
        data.clipData?.let { c -> for(i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        if(uris.isEmpty()) data.data?.let { uris.add(it) }
        if(uris.isEmpty()) return
        when(requestCode) {
            10 -> runIo("جارٍ فحص ملف IMG...") {
                val f=copyUriToTemp(uris[0],"opened_")
                val parsed=parseAfs(f)
                archiveFile=f; entries=parsed; selected=-1
                refresh("تم فتح الملف — ${parsed.size} مدخل — ${f.length()} بايت")
            }
            11 -> runIo("جارٍ استبدال العنصر...") {
                val replacement=copyUriToTemp(uris[0],"replacement_")
                val old=archiveFile!!
                val payloads=entries.map { e -> if(e.index==selected) Payload(replacement,0,replacement.length()) else Payload(old,e.offset,e.size) }
                val out=buildAfs(payloads); archiveFile=out; entries=parseAfs(out); selected=-1; refresh("تم الاستبدال. احفظ IMG جديداً.")
            }
            12 -> runIo("جارٍ حفظ IMG...") { archiveFile!!.inputStream().buffered().use { input -> contentResolver.openOutputStream(uris[0],"w")!!.buffered().use { input.copyTo(it) } }; status("تم حفظ IMG المعدل") }
            13 -> runIo("جارٍ تصدير العنصر...") { val f=pendingExport ?: return@runIo; f.inputStream().buffered().use { input -> contentResolver.openOutputStream(uris[0],"w")!!.buffered().use { input.copyTo(it) } }; pendingExport=null; status("تم تصدير العنصر") }
            14 -> runIo("جارٍ إضافة الملفات...") {
                val old=archiveFile!!
                val payloads=entries.map { Payload(old,it.offset,it.size) }.toMutableList()
                uris.forEach { u -> val f=copyUriToTemp(u,"added_"); payloads.add(Payload(f,0,f.length())) }
                val out=buildAfs(payloads); archiveFile=out; entries=parseAfs(out); selected=entries.lastIndex; refresh("تمت إضافة ${uris.size} ملف/ملفات. احفظ IMG جديداً.")
            }
            15 -> runIo("جارٍ تجهيز ملفات الهاتف...") {
                val copied = uris.map { u ->
                    val name = queryDisplayName(u) ?: "phone_file_${System.nanoTime()}.bin"
                    val f = copyUriToTemp(u,"phone_")
                    name to f
                }
                phoneFiles.clear(); phoneLabels.clear()
                copied.forEach { (name,file) -> phoneFiles.add(file); phoneLabels.add("$name  |  ${file.length()} bytes") }
                phoneSelected = if(phoneFiles.isNotEmpty()) 0 else -1
                runOnUiThread { phoneAdapter.notifyDataSetChanged(); info.text = "تم اختيار ${phoneFiles.size} ملف من الهاتف. حدد الملف ثم اضغط إضافة / نقل." }
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if(c.moveToFirst()) return c.getString(0)
        }
        return null
    }
    private fun addPhoneFiles() {
        if(archiveFile==null) { toast("افتح IMG أولاً"); return }
        if(phoneFiles.isEmpty()) { toast("اختر ملفات الهاتف أولاً"); return }
        val chosen = if(phoneSelected in phoneFiles.indices) listOf(phoneSelected) else phoneFiles.indices.toList()
        runIo("جارٍ نقل الملفات إلى IMG...") {
            val old=archiveFile!!
            val payloads=entries.map { Payload(old,it.offset,it.size) }.toMutableList()
            chosen.forEach { i -> val f=phoneFiles[i]; payloads.add(Payload(f,0,f.length())) }
            val out=buildAfs(payloads); archiveFile=out; entries=parseAfs(out); selected=entries.lastIndex
            refresh("تمت إضافة ${chosen.size} ملف. لم يتم استبدال العناصر القديمة تلقائياً لأن أسماء AFS الداخلية لم تُتحقق بعد؛ استخدم استبدال المحدد عند التأكد من العنصر.")
        }
    }

    private fun copyUriToTemp(uri:Uri,prefix:String):File {
        val f=File(cacheDir,"${prefix}${System.nanoTime()}.bin")
        contentResolver.openInputStream(uri)!!.buffered().use { input -> f.outputStream().buffered().use { input.copyTo(it,1024*1024) } }
        return f
    }
    private fun parseAfs(file:File):List<AfEntry> {
        RandomAccessFile(file,"r").use { r ->
            require(r.length()>=8) { "الملف أصغر من ترويسة AFS" }
            val h=ByteArray(8); r.readFully(h)
            require(h[0]==0x41.toByte() && h[1]==0x46.toByte() && h[2]==0x53.toByte() && h[3]==0.toByte()) { "التوقيع ليس AFS\\0" }
            val count=ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN).getInt(4)
            require(count in 1..200000) { "عدد العناصر غير منطقي: $count" }
            require(8L+count.toLong()*8L<=r.length()) { "جدول العناصر خارج حدود الملف" }
            val result=ArrayList<AfEntry>(count); val b=ByteArray(8)
            repeat(count) { i -> r.seek(8L+i*8L); r.readFully(b); val bb=ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN); val off=bb.int.toLong() and 0xffffffffL; val size=bb.int.toLong() and 0xffffffffL; require(off<=r.length() && size<=r.length()-off) { "مدخل $i خارج حدود الملف" }; result.add(AfEntry(i,off,size)) }
            return result
        }
    }
    private fun buildAfs(payloads:List<Payload>):File {
        require(payloads.isNotEmpty() && payloads.size<=200000) { "عدد العناصر غير صالح" }
        val out=File(cacheDir,"rebuilt_${System.nanoTime()}.img")
        val offsets=LongArray(payloads.size); val sizes=LongArray(payloads.size)
        RandomAccessFile(out,"rw").use { dst ->
            dst.setLength(0); dst.write(ByteArray(align(8L+payloads.size*8L,0x800L).toInt()))
            payloads.forEachIndexed { i,p ->
                val pos=align(dst.filePointer,0x800L); dst.seek(pos); offsets[i]=pos; sizes[i]=p.size
                p.file.inputStream().use { input -> input.skipFully(p.offset); copyExactly(input,dst,p.size) }
                dst.seek(align(dst.filePointer,0x800L))
            }
            require(dst.length()<=0xffffffffL) { "حجم IMG تجاوز حد AFS" }
            dst.seek(0); dst.write(byteArrayOf(0x41,0x46,0x53,0)); writeIntLE(dst,payloads.size)
            offsets.indices.forEach { i -> require(offsets[i]<=0xffffffffL && sizes[i]<=0xffffffffL); writeIntLE(dst,offsets[i].toInt()); writeIntLE(dst,sizes[i].toInt()) }
        }
        return out
    }
    private fun copyExactly(input:InputStream,out:RandomAccessFile,size:Long) { val buf=ByteArray(1024*1024); var left=size; while(left>0) { val n=input.read(buf,0,minOf(buf.size.toLong(),left).toInt()); if(n<0) throw EOFException("انتهى الملف قبل اكتمال العنصر"); out.write(buf,0,n); left-=n } }
    private fun InputStream.skipFully(n:Long) { var left=n; while(left>0) { val s=skip(left); if(s<=0) { if(read()==-1) throw EOFException(); left-- } else left-=s } }
    private fun writeIntLE(r:RandomAccessFile,v:Int) { r.write(v and 255); r.write((v ushr 8) and 255); r.write((v ushr 16) and 255); r.write((v ushr 24) and 255) }
    private fun align(v:Long,a:Long)=((v+a-1)/a)*a

    private fun exportSelected() {
        val src=archiveFile ?: run { toast("افتح IMG أولاً"); return }
        val e=entries.getOrNull(selected) ?: run { toast("اختر عنصراً أولاً"); return }
        runIo("جارٍ تجهيز التصدير...") { val f=File(cacheDir,"export_${e.index}.bin"); RandomAccessFile(src,"r").use { r -> r.seek(e.offset); f.outputStream().use { o -> val buf=ByteArray(1024*1024); var left=e.size; while(left>0){val n=r.read(buf,0,minOf(buf.size.toLong(),left).toInt()); if(n<0) throw EOFException(); o.write(buf,0,n); left-=n} } }; pendingExport=f; runOnUiThread { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/octet-stream"; putExtra(Intent.EXTRA_TITLE,"entry_${e.index.toString().padStart(4,'0')}.bin") },13) } }
    }
    private fun deleteSelected() {
        if(archiveFile==null) { toast("افتح IMG أولاً"); return }; if(selected !in entries.indices) { toast("اختر عنصراً أولاً"); return }; if(entries.size==1) { toast("لا يمكن حذف آخر عنصر"); return }
        runIo("جارٍ حذف العنصر...") { val src=archiveFile!!; val p=entries.filterIndexed { i,_->i!=selected }.map { Payload(src,it.offset,it.size) }; val out=buildAfs(p); archiveFile=out; entries=parseAfs(out); selected=-1; refresh("تم الحذف. احفظ IMG جديداً.") }
    }
    private fun runIo(message:String,work:()->Unit) { info.text=message; io.execute { try { work() } catch(e:Throwable) { status("تعذر التنفيذ: ${e.message}") } } }
    private fun refresh(message:String) { runOnUiThread { labels.clear(); entries.forEach { labels.add(String.format("Entry_%05d.bin | %d bytes | 0x%X",it.index,it.size,it.offset)) }; adapter.notifyDataSetChanged(); info.text=message } }
    private fun showSelected() { val e=entries.getOrNull(selected) ?: return; info.text="العنصر ${e.index} | الإزاحة 0x${e.offset.toString(16).uppercase()} | الحجم ${e.size} بايت" }
    private fun status(s:String) { runOnUiThread { info.text=s } }
    private fun toast(s:String) { runOnUiThread { Toast.makeText(this,s,Toast.LENGTH_LONG).show() } }
    override fun onDestroy() { io.shutdown(); super.onDestroy() }
}
